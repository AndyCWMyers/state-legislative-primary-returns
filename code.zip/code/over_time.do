* Figure 1 replication. Run from the folder containing this script and its CSV.
* The input contains district-year candidate counts and incumbent flags from
* the full merged dataset, including candidates without recorded primary returns.
* Rebuild the input locally with code/make_figure1_inputs.do.
* Optional argument: output PDF path (default: ../output/over_time.pdf).
args output_file
if `"`output_file'"' == "" {
    capture mkdir "../output"
    local output_file "../output/over_time.pdf"
}

import delimited using "figure1_district_inputs.csv", varnames(1) stringcols(2 3 4) clear
isid year state chamber district, missok
assert inrange(year, 1992, 2024) & mod(year, 2) == 0

*** Reshape long (row one row is one primary race)
reshape long n_, i(year state chamber district) j(party) string
gen contested_p = n_ > 1

*** Classify races
gen type = ""
replace type = "open" if has_dem_inc == 0 & has_rep_inc == 0
replace type = "Same-party inc" if (party == "dem" & has_dem_inc == 1) | (party == "rep" & has_rep_inc == 1)
replace type = "Out-party inc" if (party == "rep" & has_dem_inc == 1) | (party == "dem" & has_rep_inc == 1)

*** Collapse to year level 
collapse (mean) contested_p, by(year type)

*** Plot it

twoway ///
	(connected contested_p year if type == "open",           lcolor(navy)         mcolor(navy)         msymbol(none)) ///
	(connected contested_p year if type == "Same-party inc", lcolor(maroon)       mcolor(maroon)       msymbol(none)) ///
	(connected contested_p year if type == "Out-party inc",  lcolor(forest_green) mcolor(forest_green) msymbol(none)), ///
	legend(off) ///
	ylabel(, nogrid angle(horizontal) format(%3.2f)) xlabel(1992(4)2024, nogrid) ///
	ytitle("Share of Primaries Contested") xtitle("") ///
	xscale(r(1992 2024)) ///
	text(.385 2005 "Open",           color(navy)         size(small) place(n)) ///
	text(.210 2005 "Same-party inc", color(maroon)       size(small) place(n)) ///
	text(.135 2005 "Out-party inc",  color(forest_green) size(small) place(n)) ///
	graphregion(color(white)) plotregion(lcolor(none))

graph export `"`output_file'"', replace


