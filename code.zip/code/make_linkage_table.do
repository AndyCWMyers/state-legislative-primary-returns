*******************************************************************************
*** State Legislative Primary Election Data
*** Andy Myers
*** Build linkage table with population-specific denominators
*******************************************************************************

gl path "~/Dropbox/StateLegElectionData"

use "$path/analysis_data/public/stateleg_prim_elec_data.dta", clear

*** All primary candidates: retain the full public-data population.
local N_all = _N
quietly summarize year, meanonly
local all_first = r(min)
local all_last = r(max)

count if !missing(bonica_rid)
local n_dime = r(N)
count if !missing(ftm_id)
local n_ftm = r(N)

*** Primary nominees: use the existing nomination indicator, not ran_g,
*** which is itself defined by a successful Klarner match. SLERs end in 2024.
local klarner_last = 2024
count if win_primary_final == 1 & inrange(year, 1990, `klarner_last')
local N_nominees = r(N)
count if win_primary_final == 1 & inrange(year, 1990, `klarner_last') & !missing(klarner_id)
local n_klarner = r(N)

*** Identify legislators independently of the Shor-McCarty match: incumbents
*** or general-election winners. The winner lookup does not alter public data.
preserve
use state year chamber klarner_id win_g using "$path/modified_data/klarner_clean.dta", clear
destring klarner_id, replace
replace chamber = "L" if chamber == "house"
replace chamber = "U" if chamber == "senate"
isid state year chamber klarner_id
tempfile general_winners
save `general_winners'
restore
merge m:1 state year chamber klarner_id using `general_winners', keep(master match) nogen

*** Use the actual election-year coverage of the Shor-McCarty input.
*** Its preparation script maps legislative service years to election years.
preserve
use state year chamber using "~/Dropbox/FTM/modified_data/np_scores.dta", clear
keep if inlist(chamber, "house", "senate")
replace chamber = "L" if chamber == "house"
replace chamber = "U" if chamber == "senate"
duplicates drop
quietly summarize year, meanonly
local np_first = r(min)
local np_last = r(max)
gen byte np_coverage = 1
tempfile np_coverage
save `np_coverage'
restore
merge m:1 state year chamber using `np_coverage', keep(master match) nogen

gen byte legislator = (inc == 1 | win_g == 1) & np_coverage == 1
count if legislator
local N_legislators = r(N)
count if legislator & !missing(sm_id)
local n_np = r(N)

*** Numerators and denominators refer to the same population in each panel.
assert _N == `N_all'
assert `N_nominees' > 0 & `N_legislators' > 0
assert `n_klarner' <= `N_nominees' & `n_np' <= `N_legislators'
local sh_dime    : di %4.1f 100 * `n_dime' / `N_all'
local sh_ftm     : di %4.1f 100 * `n_ftm' / `N_all'
local sh_klarner : di %4.1f 100 * `n_klarner' / `N_nominees'
local sh_np      : di %4.1f 100 * `n_np' / `N_legislators'

foreach panel in all nominees legislators {
    local fmt_`panel' : di %12.0fc `N_`panel''
    local fmt_`panel' = strtrim("`fmt_`panel''")
}

*** Write LaTeX table. Panel headings supply N; rows report only percentages.
local outfile "$path/draft/output/linkage_table.tex"
cap file close texfile
file open texfile using "`outfile'", write replace
file write texfile "\begin{tabular}{llr}" _n
file write texfile "\toprule" _n
file write texfile "\textbf{Dataset} & \textbf{Content} & \textbf{Share matched} \\" _n
file write texfile "\midrule" _n
file write texfile "\multicolumn{3}{l}{\textbf{All primary candidates, `all_first'--`all_last' (N = `fmt_all')}} \\" _n
file write texfile "\addlinespace[3pt]" _n
file write texfile "DIME & Ideology estimates & `sh_dime'\% \\" _n
file write texfile "Follow the Money & Campaign contributions & `sh_ftm'\% \\" _n
file write texfile "\addlinespace[7pt]" _n
file write texfile "\multicolumn{3}{l}{\textbf{Primary nominees, 1990--`klarner_last' (N = `fmt_nominees')}} \\" _n
file write texfile "\addlinespace[3pt]" _n
file write texfile "Klarner SLERs & General-election returns & `sh_klarner'\% \\" _n
file write texfile "\addlinespace[7pt]" _n
file write texfile "\multicolumn{3}{l}{\textbf{Elected legislators, `np_first'--`np_last' (N = `fmt_legislators')}} \\" _n
file write texfile "\addlinespace[3pt]" _n
file write texfile "Shor-McCarty & Legislator ideology (NP-scores) & `sh_np'\% \\" _n
file write texfile "\bottomrule" _n
file write texfile "\end{tabular}" _n
file close texfile

di "DIME: `n_dime' / `N_all' = `sh_dime'%"
di "Follow the Money: `n_ftm' / `N_all' = `sh_ftm'%"
di "Klarner nominees: `n_klarner' / `N_nominees' = `sh_klarner'%"
di "Shor-McCarty legislators: `n_np' / `N_legislators' = `sh_np'%"
di "Table written to `outfile'"
